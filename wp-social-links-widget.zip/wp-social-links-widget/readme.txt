=== Social Links Widget ===
Contributors: Bhawna
Tags: social , widget
Requires at least: 3
Tested up to: 4.9.8
Requires PHP: 5

This is a light weight plugin to display your social profiles in wordpress widgets. 

== Description ==
This is a wordpress plugin which allows you to display  your social media profiles in wordpress widget. 

== Installation ==
Step : 1 
Install plugin and activate it.
Step : 2
Go to widgets and from the list of Available widgets pick Social Link widget .and expand it to add your social media profile links .

== Frequently Asked Questions ==
Its a easy to use plugin . But if you still have doubts do write in support section. 

== Screenshots ==
1. backend view
2. backend view
3. front view